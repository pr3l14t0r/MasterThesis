#!/bin/bash
# Purpose: Create a few files that shall exist for the INIT snapshot
mkdir ~/Documents
echo "This is a test file. Delete the file!" > ~/Documents/delete.me
echo "This files atime will get changed by 'touch -a'!" > ~/Documents/access.me
echo "This files mtime will get changed by 'touch -m'!" > ~/Documents/modify.me
echo "This files atime AND mtime will get changed by 'touch'" > ~/Documents/touch.me
echo "This files ctime will get changed through 'chmod +x'" > ~/Documents/chmod.me
echo "This is a test file. Change the content!" > ~/Documents/change.me
echo "This is a test file. Append content!" > ~/Documents/append.me
echo "This file shall get renamed!" > ~/Documents/rename.me
sleep 2