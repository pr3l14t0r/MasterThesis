#!/bin/bash
# Purpose: Change the files that have been created in the INIT snapshot
mv ~/Documents/rename.me ~/Documents/IhaveBeen.renamed
touch ~/Documents/create.me
rm -f ~/Documents/delete.me
touch -a ~/Documents/access.me
touch -m ~/Documents/modify.me
touch ~/Documents/touch.me
chmod +x ~/Documents/chmod.me
echo "This content got changed!" > ~/Documents/change.me
echo "This line has been appended to the file!" >> ~/Documents/append.me
sleep 2