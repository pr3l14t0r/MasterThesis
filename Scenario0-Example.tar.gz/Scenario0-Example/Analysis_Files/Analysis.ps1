<#
This is a small example, that: 
- creates an INIT state containaing a few manually crafted files 
- runs a noise export $Rounds times 
- runs an action export $Rounds times 
- gets the characteristic evidences based on $Rounds occurences
#>
[CmdletBinding()]
param (
    [Parameter()]
    [switch]
    #In the case that you do not need to create a new INIT-Snapshot 'cause you want to reuse an existing one, just specifiy the switch
    $SkipINIT,

    [Parameter()]
    [switch]
    $SkipNOISE
)

# [INFORMATIONAL] Used to get the duration of runtime when finished. 
$StartTime = [datetime]::Now

$ErrorActionPreference = "Stop"

Import-Module VBox4Pwsh
Import-Module PowerForensicator

# CUSTOM VARs (please change accordingly, or add any variables that you might need!)
$Rounds = 20
$ImageDirectory = "I:\Example"
$username = "vagrant"
$password = "vagrant"
$DestinationOnVM = "/home/vagrant"
$VMEnvironmentVariables = @{
    "PATH" = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin'
}

# [OPTIONAL] Set the Logfile location to the ImageDirectoy. Otherwise the logs will be set to %temp%
$env:VBOX4PWSHLogfilePath = [System.IO.Path]::Combine($ImageDirectory,"AnalysisLog.txt")

# Check first the availability of VM(s) in VirtualBox
$VMs = Get-VboxVMs | Where-Object {$_.Name -like "*kubernetes*"} | Select-Object -Property Name

if(-not $VMs)
{
    Write-VBox4PwshLog -Component "Analysis - Startup" -Message ("It seems that there are no existing VMs.") -Level Warning
    break
}

if(-not $SkipINIT){
# ==============
# PHASE 1: INIT
# ============== 
$Component = "Analysis - INIT"
# Create INIT Snapshot and export it for later usage

Write-VBox4PwshLog -Component $Component -Message ("Starting PHASE-1: Creating the Init snapshot and exporting the Image...")

#region CUSTOM STUFF
<#
    Do whatever you want in order to prepare the machine(s) for the INIT state. 
    If you have done everything, create the INIT image

    I want to create files that will get modified later on. 
    I can do this by either using SSH connection OR just placing a shell script on the machine and run it from there (which i am doing here)
    Process will be the following: "for each VM, do: Copy file to VM -> Execute file -> remove file"

    The VM-Names will be piped to the according VBoxVM-CMDLets
#>
$ShellFile = [System.IO.Path]::Combine($PSScriptRoot,"00_PreInit.sh")
$pathOnVM = [string]::concat($DestinationOnVM,'/',[System.IO.Path]::GetFileName($ShellFile))

# Copy the shell file to the VM 
$VMs | Copy-FileToVBoxVM -UserName $username -Password $password -Source $ShellFile -Destination $DestinationOnVM

# Invoke bash on the VM and run the script copied over in previous step
# runs: /bin/bash /home/vagrant/<NameOfShellFile>.sh on remote machine
$VMs | Invoke-VboxVMProcess -UserName $username -Password $password -FilePath "/bin/bash" -Params ([string]::concat("bash ",$pathOnVM)) -WaitSTDOut -WaitSTDErr -EnvironmentVariables $VMEnvironmentVariables

# Delete the script file again
# runs: '/bin/rm -f /home/vagrant/<NameOfShellFile>.sh' on remote machine
$VMs | Invoke-VboxVMProcess -UserName $username -Password $password -FilePath "/bin/rm" -Params ([string]::Concat('rm -f ',$pathOnVM)) -WaitSTDOut -WaitSTDErr -EnvironmentVariables $VMEnvironmentVariables
#endregion

#region INIT-File export
    Write-VBox4PwshLog -Component $Component -Message ("Everything configured. Creating INIT now...")
    Start-Waiting -MinutesToWait 15
    #run sync now
    foreach($vm in $VMs.Name){Invoke-SyncOnVM -VM $vm -UserName $username -Password $password -EnvironmentVariables $VMEnvironmentVariables}
    Start-Sleep -Seconds 10
    New-Init -VM $VMs.Name -ImageDirectory $ImageDirectory
#endregion

Write-VBox4PwshLog -Component $Component -Message ("Done with PHASE-1!")
# end of PHASE 1
}
else{
    Write-VBox4PwshLog -Component $Component -Message ("INIT-Phase has been skipped!")
}

if(-not $SkipNOISE){
# ===============
# PHASE 2: NOISE
# ===============
$ActionName = "Noise"
$Component = ("Analysis - "+$ActionName)

# Create NOISE Images
Write-VBox4PwshLog -Component $Component -Message ("Starting PHASE-2: Creating Noise Images and exporting the iDiff results...")

foreach ($round in (1..$Rounds)) 
{
    #region Restore INIT Snapshot
    Write-VBox4PwshLog -Component $Component -Message ("Currently working on round <"+([string]($round))+"> out of <"+([string]($Rounds))+">")

    # Restore the snapshot to INIT
    # Restore-VboxVMSnaphshot cmdlet checks also the current state of the VM and will save it if it is running.
    Write-VBox4PwshLog -Component $Component -Message ("Restore INIT snapshot(s)...")
    $VMs | Restore-VBoxVMSnapshot -SnapshotName "INIT"
    $VMs | Start-VBoxVM
    #endregion

    Write-VBox4PwshLog -Component $Component -Message ("Let the machine(s) now run in idle state.")

    # HINT: As this is the part for Noise images, we do not do anything here. We just want to fetch the normal, basic background noise on the filessystem.
    # The VM(s) will be kept running for the specified time in the 'MinutesToWait'-Parameter within the next command.

    # This will export the Image. You can specify multiple VMs by the name so that the process gets parallized. 
    # I also want to store the comparison results from DFXML (INIT compared to Noise) in a subfolder. 
    # The exported images and iDiff files will be named after the $ActionName. Therefore i am appending the current round, so that "noise.idiff" will be called "noise.1.idiff" instead.

    #region NOISE-File export
    Start-Waiting -MinutesToWait 5
    Write-VBox4PwshLog -Component $Component -Message ("Exporting Image now...")
    #run sync now
    foreach($vm in $VMs.Name){Invoke-SyncOnVM -VM $vm -UserName $username -Password $password -EnvironmentVariables $VMEnvironmentVariables}
    Start-Sleep -Seconds 10
    Invoke-ActionStateFileExport -VM $VMs.Name -ImageDirectory ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ActionName ([string]::Concat($ActionName,".",$round))
    #endregion

    Write-VBox4PwshLog -Component $Component -Message ("Done! Removing the snapshot now!")
    #Remove the snapshot and do the next round! 
    $VMs | Remove-VBoxVMSnapshot

    # Format the idiff file
    foreach ($vm in $VMs.Name) {
        Format-ActionEvidence -VM $vm -ImageDirectory ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ActionName ([string]::Concat($ActionName,".",$round))
    }
    Write-VBox4PwshLog -Component $Component -Message ("Finished round <"+([string]($round))+"> out of <"+([string]($Rounds))+">")
}

# end of PHASE 2
Write-VBox4PwshLog -Component $Component -Message ("Done with PHASE-2!")
}
else{
    Write-VBox4PwshLog -Component $Component -Message ("NOISE-Phase has been skipped!")
}

# ========================
# PHASE 3: Custom Actions
# ========================

$ActionName = "FileModifications"
$Component = ("Analysis - "+$ActionName)
# Invoking now the actions that shall get analyzed.
Write-VBox4PwshLog -Component $Component -Message ("Starting PHASE-3: Performing FileModifications, creating the images and exporting the iDiff results...") 

# In this example, the created files that now do exist in INIT state, will get changed/modified/deleted.
$ShellFile = [System.IO.Path]::Combine($PSScriptRoot,"02_FileMods.sh")
$pathOnVM = [string]::concat($DestinationOnVM,'/',[System.IO.Path]::GetFileName($ShellFile))

foreach ($round in (1..$Rounds)) 
{
    #region Restore INIT Snapshot
    Write-VBox4PwshLog -Component $Component -Message ("Currently working on round <"+([string]($round))+"> out of <"+([string]($Rounds))+">")

    # Restore the snapshot to INIT
    # Restore-VboxVMSnaphshot cmdlet checks also the current state of the VM and will save it if it is running.
    Write-VBox4PwshLog -Component $Component -Message ("Restore INIT snapshot(s)...")
    $VMs | Restore-VBoxVMSnapshot -SnapshotName "INIT"
    $VMs | Start-VBoxVM

    Write-VBox4PwshLog -Component $Component -Message ("wait a bit for everything to come up..") -Level Verbose
    Start-Sleep -Seconds 60
    #endregion Restore INIT Snapshot

    #region CUSTOM STUFF

    Write-VBox4PwshLog -Component $Component -Message ("Execution custom actions on VM(s)...")

    # Copy the shell file to the VM 
    $VMs | Copy-FileToVBoxVM -UserName $username -Password $password -Source $ShellFile -Destination $DestinationOnVM

    # Invoke bash on the VM and run the script copied over in previous step
    # runs: /bin/bash /home/vagrant/<NameOfShellFile>.sh on remote machine
    $VMs | Invoke-VboxVMProcess -UserName $username -Password $password -FilePath "/bin/bash" -Params ([string]::concat("bash ",$pathOnVM)) -WaitSTDOut -WaitSTDErr -EnvironmentVariables $VMEnvironmentVariables

    # Delete the script file again
    # runs: '/bin/rm -f/home/vagrant/<NameOfShellFile>.sh' on remote machine
    $VMs | Invoke-VboxVMProcess -UserName $username -Password $password -FilePath "/bin/rm" -Params ([string]::Concat('rm -f ',$pathOnVM)) -WaitSTDOut -WaitSTDErr -EnvironmentVariables $VMEnvironmentVariables
    #endregion

    Start-Waiting -MinutesToWait 1
    #region Export of the Action-ImageFile
    Write-VBox4PwshLog -Component $Component -Message ("Done! Exporting Images and creating iDiff-Files now!")
    #run sync now
    foreach($vm in $VMs.Name){Invoke-SyncOnVM -VM $vm -UserName $username -Password $password -EnvironmentVariables $VMEnvironmentVariables}
    Start-Sleep -Seconds 10

    # Export image(s) again!
    # I want to keep the images from the latest run,so if we are at final round, keep the image files!
    if($round -eq $Rounds){Invoke-ActionStateFileExport -VM $VMs.Name -ImageDirectory ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ActionName ([string]::Concat($ActionName,".",$round)) -KeepExportedImageFile}
    else{Invoke-ActionStateFileExport -VM $VMs.Name -ImageDirectory ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ActionName ([string]::Concat($ActionName,".",$round))}

    Write-VBox4PwshLog -Component $Component -Message ("Done! Removing the snapshot now!")
    #Remove the snapshot and do the next round! 
    $VMs | Remove-VBoxVMSnapshot
    #endregion

    # Format the idiff file
    foreach ($vm in $VMs.Name) {
        Format-ActionEvidence -VM $vm -ImageDirectory ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ActionName ([string]::Concat($ActionName,".",$round)) -StringsToReplace $StringsToReplace
    }
    Write-VBox4PwshLog -Component $Component -Message ("Finished round <"+([string]($round))+"> out of <"+([string]($Rounds))+">")
}

Write-VBox4PwshLog -Component $Component -Message ("Done with PHASE-3!")

# Last step: Substract <ACTION> evidences from <NOISE> evidences to get characteristic evidences
Write-VBox4PwshLog -Component $Component -Message ("Finishing now by substracting the the <NOISE> evidences from <"+$ActionName+"> evidences!")

foreach($vm in $VMs.Name)
{
    $null = Get-CharacteristicEvidence -VM $vm -ActionName $ActionName -ImageDirectory $ImageDirectory
}

$EndTime = [datetime]::Now

Write-VBox4PwshLog -Component $Component -Message ("Started at: "+$StartTime.ToString("s")) -Level Verbose
Write-VBox4PwshLog -Component $Component -Message ("Finished at: "+$EndTime.ToString("s")) -Level Verbose
Write-VBox4PwshLog -Component $Component -Message ("Runtime: "+($EndTime-$StartTime).ToString("G")) -Verbose