#!/bin/bash
echo "This script will download sample files from the repository <https://github.com/pr3l14t0r/Investigations/>"
echo "The files are located in path: <Kubernetes/DeployCraftedContainer/CraftedFiles>"

# Download First file 
echo "Download <File03.2MB.tmp>"
wget https://github.com/pr3l14t0r/Investigations/raw/main/Kubernetes/DeployCraftedContainer/CraftedFiles/File03.2MB.tmp

echo "Verifiying Checksum"

echo "verifying checksums"
sha1sumfile=`sha1sum File03.2MB.tmp | awk '{ print toupper($1) }'`

if [ "$sha1sumfile" = "037C75E2588A8E6E44571D786581A7AF3EFCAE5F" ]; then 
    echo "OK"
else
    echo "NOT OK! Checksum does differ!"
fi

echo "Downloading <File04.2MB.tmp>"
wget https://github.com/pr3l14t0r/Investigations/raw/main/Kubernetes/DeployCraftedContainer/CraftedFiles/File04.2MB.tmp

echo "verifying checksums"
sha1sumfile=`sha1sum File04.2MB.tmp | awk '{ print toupper($1) }'`

if [ "$sha1sumfile" = "12DC198BF27A6DBCD1F768E327420D5141413E8F" ]; then 
    echo "OK"
else
    echo "NOT OK! Checksum does differ!"
fi

echo "Finished download and verified the files!"