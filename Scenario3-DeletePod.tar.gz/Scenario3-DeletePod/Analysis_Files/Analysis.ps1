[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $KubeConfig,

    [Parameter()]
    [switch]
    #In the case that you do not need to create a new INIT-Snapshot 'cause you want to reuse an existing one, just specifiy the switch
    $SkipINIT,

    [Parameter()]
    [switch]
    $SkipNOISE
)

$StartTime = [datetime]::Now

$ErrorActionPreference = "Stop"

Import-Module VBox4Pwsh
Import-Module PowerForensicator

$Rounds = 20
$ImageDirectory = "I:\Kubernetes_DeletePod"

$VMUserName = "vagrant"
$VMUserPassword = "vagrant"
$VMEnvironmentVariables = @{
    "PATH" = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin'
}

$env:VBOX4PWSHLogfilePath = [System.IO.Path]::Combine($ImageDirectory,"AnalysisLog.txt")


# ===================
# PHASE 0: Pre-Checks
# ===================
$Component = "Pre-Checks"
Write-VBox4PwshLog -Message ("Starting up the Analysis. Exectuing pre checks...") -Component $Component

# Check first the availability of VM(s) in VirtualBox
$VMs = Get-VboxVMs | Where-Object {$_.Name -like "*kubernetes*"} | Select-Object -Property Name

if(-not $VMs)
{
    Write-VBox4PwshLog -Component $Component -Message ("It seems that there are no existing VMs.") -Level Warning
    break
}

# This helper cmdlet checks and verifies the settings of Kubeconfig. Just leave it as it is, even though the variables are empty. It will handle all possible scenarios!
Test-Kubectl -VM ($VMs.Name | Where-Object {$_ -like "*master*"}) -KubeConfig $KubeConfig -VMUserName $VMUserName -VMUserPassword $VMUserPassword

Write-VBox4PwshLog -Message ("Finished Pre-Checks!")

if(-not $SkipINIT){
# ==============
# PHASE 1: INIT
# ============== 
$Component = "Analysis - INIT"
# Create INIT Snapshot and export it for later usage

Write-VBox4PwshLog -Component $Component -Message ("Starting PHASE-1: Creating the Init snapshot and exporting the Image...")

# The init snapshot should already contain the running pod 'craftedfiles-pod'
Write-VBox4PwshLog -Component $Component -Message ("wait a minute for everything to come up..") -Level Verbose
Start-Sleep -Seconds 60

# Applying now the cluster configurations
Write-VBox4PwshLog -Component $Component -Message ("Applying the pod now...")

# The $ret variable will fetch the returned information from kubectl as already parsed JSON, in case you need to output some IDs or so..
$Pods = Invoke-Kubectl -kubectlArgs ("apply","-f",[System.IO.Path]::Combine($PSScriptRoot,"craftedPod.yaml"),'-o','json') | ConvertFrom-Json

# Do your checks in order to determine whether your tasks have finished or not!
#   This one checks the kubectl deployments. It will continue when all scheduled resources from the deployment are available
Write-VBox4PwshLog -Component $Component -Message ("Waiting now for the changes to be applied") -Level Verbose

$Pods = Wait-PodDeployment -File ([System.IO.Path]::Combine($PSScriptRoot,"craftedPod.yaml"))

Write-VBox4PwshLog -Component $Component -Message ("Pod applied. Invoke file download now...")
# Now invoke the file download!
# Execute the script on pod and fetch return value
# 'kubectl exec' should be run with '-it' so that everything will be redirected to STDOut.
#  see: https://stackoverflow.com/questions/69393723/kubectl-exec-output-not-getting-stored-in-variable
$ret = Invoke-Kubectl -kubectlArgs ("exec","-f",[System.IO.Path]::Combine($PSScriptRoot,"craftedPod.yaml"),"-it","--","./DownloadFiles.sh")

# Do your checks in order to determine whether your tasks have finished or not!
#   This one checks if a certain line has been returned from the script
if($ret.Contains("Finished download and verified the files!")){Write-VBox4PwshLog -Component $Component -Message ("Succesfull!")}
else {Write-VBox4PwshLog -Component $Component -Message ("NOT succesfull! Please check logfile...")}

# Check for strings to replace
$StringsToReplace = Find-StringsToReplaceInPods -Pods $Pods

Write-VBox4PwshLog -Component $Component -Message ("All done! Creating INIT Snapshot now and exporting the image(s)...")

foreach($vm in $VMs.Name){Invoke-SyncOnVM -VM $vm -UserName $VMUserName -Password $VMUserPassword -EnvironmentVariables $VMEnvironmentVariables}
Start-Sleep -Seconds 10

# Fetch and Export the Mount Points
$INITFileSystemMounts = @()
foreach($vm in $VMs.Name)
{
    $OutFileName = ([System.IO.Path]::Combine($ImageDirectory,([string]::Concat($vm,'_','INIT.FileSystemMounts','.txt'))))
    $FSMounts = Get-FSMounts -VM $vm -VMUserName $VMUserPassword -VMUserPassword $VMUserPassword -OutFileName $OutFileName

    $INITFileSystemMounts += [PSCustomObject]@{
        "VMName" = $vm
        "FSMounts" = $FSMounts
    }

    # Store a backup of this variable. In case you want to rerun Noise and/or Action, but skip Init, we need this variable to be present again.
    $INITFileSystemMounts | Export-Clixml -Path ([System.IO.Path]::Combine($ImageDirectory,"_INITFileSystemMounts.variable.backup.xml")) -Force
}

# Export Disk Image
New-Init -VM $VMs.Name -ImageDirectory $ImageDirectory

}
else{
    # if INIT phase has been skipped...

    Write-VBox4PwshLog -Component $Component -Message ("INIT-Phase has been skipped!")
    Write-VBox4PwshLog -Component $Component ("Restoring INIT FileSystem mounts")
    # Restore the snapshot to INIT
    # Restore-VboxVMSnaphshot cmdlet checks also the current state of the VM and will save it if it is running.
    $BackupPath = ([System.IO.Path]::Combine($ImageDirectory,"_INITFileSystemMounts.variable.backup.xml"))
    if(Test-Path -Path $BackupPath)
    {
        Write-VBox4PwshLog -Component $Component -Message ('Found a backup of variable "$INITFileSystemMounts" at path <'+$BackupPath+'>. Importing it!') -Level Verbose
        $INITFileSystemMounts = Import-Clixml $BackupPath
    }
    else
    {
        Write-VBox4PwshLog -Component $Component -Message ('Unable to find a backup of the variable "$INITFileSystemMounts". Restoring INIT snapshot and re-setting it now!') -Level Verbose
        Write-VBox4PwshLog -Component $Component -Message ("Restore INIT snapshot(s)...")
        $VMs | Restore-VBoxVMSnapshot -SnapshotName "INIT"
        $VMs | Start-VBoxVM
        # Fetch and Export the Mount Points
        $INITFileSystemMounts = @()
        foreach($vm in $VMs.Name)
        {
            $FSMounts = Get-FSMounts -VM $vm -VMUserName $VMUserPassword -VMUserPassword $VMUserPassword
            $INITFileSystemMounts += [PSCustomObject]@{
                "VMName" = $vm
                "FSMounts" = $FSMounts
            }
        }
    }
}

if(-not $SkipNOISE){
# ===============
# PHASE 2: NOISE
# ===============
$ActionName = "Noise"
$Component = ("Analysis - "+$ActionName)
# Create path for the Action
if(-not (Test-Path -Path ([System.IO.Path]::Combine($ImageDirectory,$ActionName)))){$null = New-Item ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ItemType Directory -Force}

# Create NOISE Images
Write-VBox4PwshLog -Component $Component -Message ("Starting PHASE-2: Creating Noise Images and exporting the iDiff results...")

foreach ($round in (1..$Rounds)) 
{
    #region Restore INIT Snapshot
    Write-VBox4PwshLog -Component $Component -Message ("Currently working on round <"+([string]($round))+"> out of <"+([string]($Rounds))+">")

    # Restore the snapshot to INIT
    # Restore-VboxVMSnaphshot cmdlet checks also the current state of the VM and will save it if it is running.
    Write-VBox4PwshLog -Component $Component -Message ("Restore INIT snapshot(s)...")
    $VMs | Restore-VBoxVMSnapshot -SnapshotName "INIT"
    $VMs | Start-VBoxVM
    #endregion

    Write-VBox4PwshLog -Component $Component -Message ("Let the machine(s) now run in idle state. Waiting Time will be displayed...")

    Start-Waiting -MinutesToWait 5
    foreach($vm in $VMs.Name){Invoke-SyncOnVM -VM $vm -UserName $VMUserName -Password $VMUserPassword -EnvironmentVariables $VMEnvironmentVariables}
    Start-Sleep -Seconds 10

    # Fetch and Export the Mount Points
    foreach($vm in $VMs.Name)
    {
        $OutFileName = ([System.IO.Path]::Combine($ImageDirectory,$ActionName,([string]::concat($vm,'.',$ActionName,'.',$round,'.FileSystemMounts.txt'))))
        $FSMounts = Get-FSMounts -VM $vm -VMUserName $VMUserPassword -VMUserPassword $VMUserPassword -OutFileName $OutFileName

        # And now invoke comparison
        $INITMounts = $INITFileSystemMounts | Where-Object {$_.VMName -like ("*"+$vm+"*")}

        # Invoke Comparison!
        Compare-FSMounts -ReferenceFSMount $INITMounts.FSMounts -DifferenceFSMount $FSMounts | Set-Content -Path ([System.IO.Path]::ChangeExtension($OutFileName,".Difference.txt")) -Force
    }

    # Export RAW image, invoke fiwalkd and idiff
    Invoke-ActionStateFileExport -VM $VMs.Name -ImageDirectory ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ActionName ([string]::Concat($ActionName,".",$round))

    Write-VBox4PwshLog -Component $Component -Message ("Done! Removing the snapshot now!")
    #Remove the snapshot and do the next round! 
    $VMs | Remove-VBoxVMSnapshot

    # Format the idiff file
    foreach ($vm in $VMs.Name) {
        Format-ActionEvidence -VM $vm -ImageDirectory ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ActionName ([string]::Concat($ActionName,".",$round))
    }
    Write-VBox4PwshLog -Component $Component -Message ("Finished round <"+([string]($round))+"> out of <"+([string]($Rounds))+">")
}

Write-VBox4PwshLog -Component $Component -Message ("Done with PHASE-2!")
}
else
{
    Write-VBox4PwshLog -Component $Component -Message ("NOISE-Phase has been skipped!")
}
# end of PHASE 2

# ========================
# PHASE 3: Custom Actions
# ========================

$ActionName = "DeletePod"
$Component = ("Analysis - "+$ActionName)
# Create path for the Action
if(-not (Test-Path -Path ([System.IO.Path]::Combine($ImageDirectory,$ActionName)))){$null = New-Item ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ItemType Directory -Force}

# Invoking now the actions that shall get analyzed.
Write-VBox4PwshLog -Component $Component -Message ("Starting PHASE-3: Performing the FileDownload...") 

foreach ($round in (1..$Rounds)) 
{
    #region Restore INIT Snapshot
    Write-VBox4PwshLog -Component $Component -Message ("Currently working on round <"+([string]($round))+"> out of <"+([string]($Rounds))+">")

    # Restore the snapshot to INIT
    # Restore-VboxVMSnaphshot cmdlet checks also the current state of the VM and will save it if it is running.
    Write-VBox4PwshLog -Component $Component -Message ("Restore INIT snapshot(s)...")
    $VMs | Restore-VBoxVMSnapshot -SnapshotName "INIT"
    $VMs | Start-VBoxVM

    Write-VBox4PwshLog -Component $Component -Message ("wait a minute for everything to come up..") -Level Verbose
    Start-Sleep -Seconds 60
    #endregion Restore INIT Snapshot

    # Applying now the cluster configurations
    Write-VBox4PwshLog -Component $Component -Message ("Deleting the pod now!")

    # Deleting the pod here
    $ret = Invoke-Kubectl -kubectlArgs ("delete","-f",[System.IO.Path]::Combine($PSScriptRoot,"craftedPod.yaml"),'-o','name') -RetryCount 30
    
    # Do your checks in order to determine whether your tasks have finished or not!
    #   This one checks if a certain line has been returned from the script
    if($ret -like "pod*deleted*"){Write-VBox4PwshLog -Component $Component -Message ("Succesfull!")}
    else {Write-VBox4PwshLog -Component $Component -Message ("NOT succesfull! Please check logfile...")}

    Write-VBox4PwshLog -Component $Component -Message ("All done! Exporting Image now and create the iDiff(s)")

    foreach($vm in $VMs.Name){Invoke-SyncOnVM -VM $vm -UserName $VMUserName -Password $VMUserPassword -EnvironmentVariables $VMEnvironmentVariables}
    Start-Sleep -Seconds 10

    # Fetch and Export the Mount Points
    foreach($vm in $VMs.Name)
    {
        $OutFileName = ([System.IO.Path]::Combine($ImageDirectory,$ActionName,([string]::concat($vm,'.',$ActionName,'.',$round,'.FileSystemMounts.txt'))))
        $FSMounts = Get-FSMounts -VM $vm -VMUserName $VMUserPassword -VMUserPassword $VMUserPassword -OutFileName $OutFileName -StringsToReplace $StringsToReplace

        # And now invoke comparison
        $INITMounts = $INITFileSystemMounts | Where-Object {$_.VMName -like ("*"+$vm+"*")}

        # Invoke Comparison!
        Compare-FSMounts -ReferenceFSMount $INITMounts.FSMounts -DifferenceFSMount $FSMounts | Set-Content -Path ([System.IO.Path]::ChangeExtension($OutFileName,".Difference.txt")) -Force
    }

    # I want to keep the images from the latest run,so if we are at final round, keep the image files!
    if($round -eq $Rounds){Invoke-ActionStateFileExport -VM $VMs.Name -ImageDirectory ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ActionName ([string]::Concat($ActionName,".",$round)) -KeepExportedImageFile}
    else{Invoke-ActionStateFileExport -VM $VMs.Name -ImageDirectory ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ActionName ([string]::Concat($ActionName,".",$round))}

    Write-VBox4PwshLog -Component $Component -Message ("Done! Removing the snapshot now!")
    #Remove the snapshot and do the next round! 
    $VMs | Remove-VBoxVMSnapshot

    # Format the idiff file
    foreach ($vm in $VMs.Name) {
        Format-ActionEvidence -VM $vm -ImageDirectory ([System.IO.Path]::Combine($ImageDirectory,$ActionName)) -ActionName ([string]::Concat($ActionName,".",$round)) -StringsToReplace $StringsToReplace
    }

    Write-VBox4PwshLog -Component $Component -Message ("Finished round <"+([string]($round))+"> out of <"+([string]($Rounds))+">")
}

# Last step: Substract <ACTION> evidences from <NOISE> evidences to get characteristic evidences
Write-VBox4PwshLog -Component $Component -Message ("Finishing now by substracting the the <NOISE> evidences from <"+$ActionName+"> evidences!")

foreach($vm in $VMs.Name)
{
    # FileSystem
    $null = Get-CharacteristicEvidence -VM $vm -ActionName $ActionName -ImageDirectory $ImageDirectory -MinCount 16

    # FileSystem - Mounts
    $null = Get-FSMountCharacteristicEvidences -VM $vm -ActionName $ActionName -ImageDirectory $ImageDirectory -MinCount 16
}

$EndTime = [datetime]::Now

Write-VBox4PwshLog -Component $Component -Message ("Started at: "+$StartTime.ToString("s")) -Level Verbose
Write-VBox4PwshLog -Component $Component -Message ("Finished at: "+$EndTime.ToString("s")) -Level Verbose
Write-VBox4PwshLog -Component $Component -Message ("Runtime: "+($EndTime-$StartTime).ToString("G")) -Verbose